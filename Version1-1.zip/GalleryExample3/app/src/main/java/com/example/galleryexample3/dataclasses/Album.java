package com.example.galleryexample3.dataclasses;

public class Album {
}
